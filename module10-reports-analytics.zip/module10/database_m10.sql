-- ============================================================
-- Module 10: Reports & Analytics
-- Run AFTER database_m3.sql and database_m9.sql
-- ============================================================

USE auditorium_booking;

-- Extra indexes for fast report queries
ALTER TABLE bookings
  ADD INDEX IF NOT EXISTS idx_override  (override_by),
  ADD INDEX IF NOT EXISTS idx_reminder  (reminder_sent),
  ADD INDEX IF NOT EXISTS idx_created   (created_at);

ALTER TABLE equipment_requests
  ADD INDEX IF NOT EXISTS idx_eq_name   (equipment_name);

ALTER TABLE notification_log
  ADD INDEX IF NOT EXISTS idx_nl_event  (trigger_event),
  ADD INDEX IF NOT EXISTS idx_nl_sent   (sent_at);
